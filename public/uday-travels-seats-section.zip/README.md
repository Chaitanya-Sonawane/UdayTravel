# Uday Travels — Seats Section Module

A complete, self-contained bus seat reservation and real-time locking module for Uday Travels.

## Package Contents

```
seats-section/
├── app/
│   ├── seats/
│   │   └── page.tsx              # React UI: interactive seat map, passenger selector, hold timer
│   └── api/
│       └── seats/
│           ├── route.ts          # GET /api/seats (fetch live seat chart from Firestore)
│           ├── hold/
│           │   └── route.ts      # POST /api/seats/hold (atomic seat lock with 5-min TTL)
│           └── stream/
│               └── route.ts      # GET /api/seats/stream (Server-Sent Events for real-time sync)
├── lib/
│   ├── booking-store.ts          # Zustand store for seat & multi-passenger assignments
│   ├── config/
│   │   └── seats.ts              # Canonical layout config (A-J rows, 1-5 columns, 50 seats)
│   ├── data/
│   │   └── seats.repo.ts         # Firestore data access repository
│   └── domain/
│       └── seats/
│           └── hold.ts           # Cryptographic seat hold token & validation engine
├── tests/
│   └── seat-hold.test.ts         # Vitest unit & concurrency tests for seat holds
├── seats.css                     # Dedicated CSS styling for the seat layout
└── README.md                     # Integration documentation
```

## Bus Seat Layout Specification

- **Total Capacity**: 50 Seats
- **Configuration**: 2x3 (2 seats on Left, Aisle, 3 seats on Right)
- **Rows**: 10 rows labeled `A` through `J`
- **Columns**:
  - Left side: `1`, `2`
  - Center: Aisle
  - Right side: `3`, `4`, `5`
- **Seat IDs**: `A1`, `A2`, `A3`, `A4`, `A5` ... `J1` to `J5`

## Seat States & Visual Classes

| Status | CSS Class | Description |
|---|---|---|
| `available` | `.available` | Available for selection (White with hover effect) |
| `selected` | `.is-selected` | Currently chosen by the active passenger (Amber `#FFB21A`) |
| `booked` / `male` / `held` | `.booked` | Already reserved / booked (Disabled gray `#E5E7EB`) |
| `female` / `for-female` | `.female` | Reserved for women passengers (Pink `#FFF0F6`) |

## How to Integrate

1. **Copy Files**:
   - Copy `app/seats/page.tsx` into your Next.js `app/seats/`
   - Copy `app/api/seats/` into your Next.js `app/api/seats/`
   - Copy `lib/` files into your project's `lib/` directory
2. **Include Styles**:
   - Import `seats.css` in your `app/seats/page.tsx` or merge into `app/globals.css`.
3. **Dependencies**:
   - `zustand` (`npm i zustand`)
   - `lucide-react` (`npm i lucide-react`)
   - Firebase Admin SDK for server-side atomic locking.
