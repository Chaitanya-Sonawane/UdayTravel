import { createHmac, timingSafeEqual } from 'node:crypto'
import { AppError, ErrorCodes } from '../../errors/app-error'
import { SeatsRepository } from '../../data/seats.repo'
import { AvailabilityRepository } from '../../data/availability.repo'
import { getRoute, RouteId } from '../../config/routes'
import { BASE_FARE_INR, HOLD_TTL_MS, SEATS_PER_BUS } from '../../config/rules'
import { rupeesToPaise, computeBookingTotal } from '../../money'

function getHoldSecret(): string {
  return (
    process.env.HOLD_SIGNING_SECRET ||
    process.env.QR_SECRET ||
    process.env.ADMIN_SECRET_KEY ||
    'uday_hold_signing_secret_fallback_2026'
  )
}

export function signHoldToken(
  grp: string,
  uid: string,
  seatIds: string[],
  expiresAt: number
): string {
  const secret = getHoldSecret()
  const payload = `${grp}:${uid}:${[...seatIds].sort().join(',')}:${expiresAt}`
  return createHmac('sha256', secret).update(payload).digest('hex')
}

export function verifyHoldToken(
  token: string,
  grp: string,
  uid: string,
  seatIds: string[],
  expiresAt: number
): boolean {
  try {
    const expected = signHoldToken(grp, uid, seatIds, expiresAt)
    const bufA = Buffer.from(token, 'hex')
    const bufB = Buffer.from(expected, 'hex')
    if (bufA.length !== bufB.length) return false
    return timingSafeEqual(bufA, bufB)
  } catch {
    return false
  }
}

export interface PlaceSeatHoldParams {
  uid: string
  routeId: RouteId
  date: string
  tripId: string
  seatIds: string[]
}

export interface PlaceSeatHoldResult {
  grp: string
  holdToken: string
  holdExpiresAt: number
  seatIds: string[]
  perSeatPaise: number
  totalPaise: number
  busName: string
}

export async function placeSeatHold(params: PlaceSeatHoldParams): Promise<PlaceSeatHoldResult> {
  const { uid, routeId, date, tripId, seatIds } = params

  if (!seatIds || seatIds.length === 0 || seatIds.length > 6) {
    throw new AppError(
      ErrorCodes.INVALID_INPUT,
      'Must select between 1 and 6 seats for a booking hold'
    )
  }

  const routeConfig = getRoute(routeId)
  if (!routeConfig) {
    throw new AppError(ErrorCodes.INVALID_INPUT, `Route '${routeId}' is not supported`)
  }

  // Fetch availability to determine fare and bus name
  const availDoc = await AvailabilityRepository.getAvailabilityDoc(routeId, date)
  let fareRupees = BASE_FARE_INR
  let busName = 'Uday Express'

  if (availDoc?.trips?.[tripId]) {
    const tr = availDoc.trips[tripId]
    if (tr.fare) fareRupees = tr.fare
    if (tr.busName) busName = tr.busName
  } else if (availDoc?.customTrips && Array.isArray(availDoc.customTrips)) {
    const ct = availDoc.customTrips.find((t) => t.tripId === tripId)
    if (ct) {
      if (ct.fare) fareRupees = ct.fare
      if (ct.busName) busName = ct.busName
    }
  }

  const perSeatPaise = rupeesToPaise(fareRupees)
  const totalPaise = computeBookingTotal(perSeatPaise, seatIds.length)

  const grp = `hold_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
  const holdExpiresAt = Date.now() + (HOLD_TTL_MS || 300000)

  // Place atomic hold in bus_seats repository
  await SeatsRepository.placeHold(tripId, date, seatIds, uid, grp, holdExpiresAt)

  const holdToken = signHoldToken(grp, uid, seatIds, holdExpiresAt)

  return {
    grp,
    holdToken,
    holdExpiresAt,
    seatIds,
    perSeatPaise,
    totalPaise,
    busName,
  }
}
